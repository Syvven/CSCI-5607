#include <iostream>

#include "vec3.h"

using namespace std;

int main(int argc, char** argv)
{
    /* vec3 testing */
    vec3 v1(0, 3, 4);
    


    return 0;
}